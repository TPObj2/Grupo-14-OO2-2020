package com.unla.Grupo14OO22020;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Grupo14OO22020Application {

	public static void main(String[] args) {
		SpringApplication.run(Grupo14OO22020Application.class, args);
	}

}
