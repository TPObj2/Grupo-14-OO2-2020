package com.unla.Grupo14OO22020;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Grupo14OO22020ApplicationTests {

	@Test
	void contextLoads() {
	}

}
